# Magasinet Bil, Båd & Bike's - Svendeprøve
Min webintegrator svendeprøve oktober 2018